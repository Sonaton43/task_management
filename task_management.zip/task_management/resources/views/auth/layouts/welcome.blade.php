<!-- ======= Hrader Start ======= -->
@include('layouts.header')
<!-- =======  Hrader End  ======= -->

@yield('authsection')

<!-- ======= Sidebar Start ======= -->
@include('layouts.script')
<!-- =======  Sidebar End  ======= -->

