 <!-- Vendor JS Files -->
 <script src="<?php echo e(asset('assets')); ?>/vendor/apexcharts/apexcharts.min.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/chart.js/chart.umd.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/echarts/echarts.min.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/quill/quill.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/simple-datatables/simple-datatables.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/tinymce/tinymce.min.js"></script>
 <script src="<?php echo e(asset('assets')); ?>/vendor/php-email-form/validate.js"></script>

 <!-- Template Main JS File -->
 <script src="<?php echo e(asset('assets')); ?>/js/main.js"></script>

</body>

</html><?php /**PATH C:\laragon\www\Login Authentication\resources\views/layouts/script.blade.php ENDPATH**/ ?>