<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <?php echo e(date('Y')); ?> <strong><span>Task-Management-System</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a target="blank" href="https://www.facebook.com/shartho.kundu">Sonaton Kundu</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a><?php /**PATH C:\laragon\www\Login Authentication\resources\views/layouts/footer.blade.php ENDPATH**/ ?>