<!-- ======= Hrader Start ======= -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- =======  Hrader End  ======= -->

    <!-- ======= Navbar Start ======= -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =======  Navbar End  ======= -->

    <!-- ======= Sidebar Start ======= -->
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =======  Sidebar End  ======= -->

  

  

  <main id="main" class="main">
      <?php echo $__env->yieldContent('section'); ?>
  </main><!-- End #main -->

  <!-- ======= Sidebar Start ======= -->
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- =======  Sidebar End  ======= -->

<!-- ======= Sidebar Start ======= -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- =======  Sidebar End  ======= -->

<?php /**PATH C:\laragon\www\Login Authentication\resources\views/layouts/welcome.blade.php ENDPATH**/ ?>