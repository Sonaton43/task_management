<!-- ======= Hrader Start ======= -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- =======  Hrader End  ======= -->

    <!-- ======= Navbar Start ======= -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =======  Navbar End  ======= -->

    <!-- ======= Sidebar Start ======= -->
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- =======  Sidebar End  ======= -->

  

  

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

       <?php echo $__env->yieldContent('section'); ?>

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Sidebar Start ======= -->
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- =======  Sidebar End  ======= -->

<!-- ======= Sidebar Start ======= -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- =======  Sidebar End  ======= -->

<?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/welcome.blade.php ENDPATH**/ ?>