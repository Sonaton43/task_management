
<?php $__env->startSection('section'); ?>

  <div class="pagetitle">
    <h1>Teammates</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Add-New Teammate</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

    <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
            

                <form class="row g-3 my-2" action="<?php echo e(Route('user.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6">
                        <label for="name" class="form-label">Teammate Name<span class=" text-danger">*</span></label>
                        <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" name="name" id="name">
                        <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                    </div>

                    <div class="col-md-6">
                        <label for="email" class="form-label">Email<span class=" text-danger">*</span></label>
                        <input type="email" class="form-control" value="<?php echo e(old('email')); ?>" name="email" id="email">
                        <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                    </div>

                    <div class="col-md-4">
                        <label for="phone" class="form-label">Phone<span class=" text-danger">*</span></label>
                        <input type="number" class="form-control" value="<?php echo e(old('phone')); ?>" name="phone" id="phone">
                        <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                    </div>

                    <div class="col-md-4">
                        <label for="designation" class="form-label">Designation</label>
                        <input type="text" class="form-control" value="<?php echo e(old('designation')); ?>" name="designation" id="designation">
                        <div class="text-danger"><?php echo e($errors->first('designation')); ?></div>
                    </div>

                    <div class="col-md-4">
                        <label for="role" class="form-label">Role<span class=" text-danger">*</span></label>
                        <select class="form-select"  name="role" id="role" required>
                            <option disabled selected>Choose...</option>
                            <option value="manager">Manager</option>
                            <option value="teammate">Teammate</option>
                        </select>
                        <div class="text-danger"><?php echo e($errors->first('role')); ?></div>
                    </div>

                    <div class="col-md-6">
                        <label for="password" class="form-label">Password<span class=" text-danger">*</span></label>
                        <input type="password" class="form-control" value="<?php echo e(old('password')); ?>" name="password" id="password">
                        <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                    </div>

                    <div class="col-md-6">
                        <label for="cpassword" class="form-label">Confirm Password<span class=" text-danger">*</span></label>
                        <input type="password" class="form-control" value="<?php echo e(old('cpassword')); ?>" name="cpassword" id="cpassword">
                        <div class="text-danger"><?php echo e($errors->first('cpassword')); ?></div>
                    </div>


                    <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </form>
                <!-- End Table with stripped rows -->
            </div>
        </div>
        </div>

    </div>
    </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Login Authentication\resources\views/Users/create.blade.php ENDPATH**/ ?>