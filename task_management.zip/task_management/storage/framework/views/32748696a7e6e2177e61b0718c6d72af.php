<?php $__env->startComponent('mail::message'); ?>
Hey, welcome to Mailtrap! 

<h2>Welcome <?php echo e($user->email); ?></h2>
<p>Thank you for signing up for Mailtrap.</p>
<p>Verify your email address by clicking the button below.</p>
<?php $__env->startComponent('mail::button',['url' => url('mailcheck/'.$user->remember_token)]); ?>
Verify
<?php echo $__env->renderComponent(); ?>
<p>Thanks</p>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\laragon\www\Login Authentication\resources\views/auth/emails/register.blade.php ENDPATH**/ ?>