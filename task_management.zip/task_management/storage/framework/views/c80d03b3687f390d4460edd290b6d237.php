
<?php $__env->startSection('section'); ?>

  <div class="pagetitle">
    <h1>Users</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Edit</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

    <!-- Left side columns -->
        <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <?php echo $__env->make('auth.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="row g-3 my-2" action="<?php echo e(Route('user.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($item->id); ?>" name="token">
                    <div class="col-md-6">
                        <label for="name" class="form-label">User Name<span class=" text-danger">*</span></label>
                        <input type="text" class="form-control" value="<?php echo e($item->name); ?>" name="name" id="name">
                        <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                    </div>

                    <div class="col-md-6">
                        <label for="email" class="form-label">Email<span class=" text-danger">*</span></label>
                        <input type="email" class="form-control" value="<?php echo e($item->email); ?>" name="email" id="email">
                        <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                    </div>

                    <div class="col-md-4">
                        <label for="phone" class="form-label">Phone<span class=" text-danger">*</span></label>
                        <input type="number" class="form-control" value="<?php echo e($item->phone); ?>" name="phone" id="phone">
                        <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                    </div>

                    <div class="col-md-4">
                        <label for="designation" class="form-label">Designation</label>
                        <input type="text" class="form-control" value="<?php echo e($item->designation); ?>" name="designation" id="designation">
                        <div class="text-danger"><?php echo e($errors->first('designation')); ?></div>
                    </div>

                    <div class="col-md-4">
                        <label for="role" class="form-label">Role<span class=" text-danger">*</span></label>
                        <select class="form-select"  name="role" id="role" required>
                            <option disabled selected>Choose...</option>
                            <option value="manager" <?php if($item->role == "manager"): ?> selected <?php endif; ?>>Manager</option>
                            <option value="teammate" <?php if($item->role == "teammate"): ?> selected <?php endif; ?>>Teammate</option>
                        </select>
                        <div class="text-danger"><?php echo e($errors->first('role')); ?></div>
                    </div>

                    <div class="col-12">
                        <label>
                            <input type="checkbox" id="change-password-checkbox"> Change Password?
                        </label>
                    </div>
                    
                    <div class="col-12" id="password-fields" style="display: none;">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="password" class="form-label">New Password<span class=" text-danger">*</span></label>
                                <input type="password" class="form-control" value="<?php echo e(old('password')); ?>" name="password" id="password">
                                <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                            </div>
                        
                            <div class="col-md-6">
                                <label for="cpassword" class="form-label">Confirm Password<span class=" text-danger">*</span></label>
                                <input type="password" class="form-control" value="<?php echo e(old('cpassword')); ?>" name="cpassword" id="cpassword">
                                <div class="text-danger"><?php echo e($errors->first('cpassword')); ?></div>
                            </div>
                        </div>
                    </div>


                    <div class="text-center">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </form>
                <!-- End Table with stripped rows -->
            </div>
        </div>
        </div>

    </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#change-password-checkbox').on('change', function() {
                if ($(this).is(':checked')) {
                    $('#password-fields').show();
                } else {
                    $('#password-fields').hide();
                }
            });
        });
    </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Login Authentication\resources\views/Users/edit.blade.php ENDPATH**/ ?>