
<?php $__env->startSection('section'); ?>

  <div class="pagetitle">
    <h1>Tasks</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Tasks</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

    <!-- Left side columns -->
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body" style="overflow-x: scroll;white-space: nowrap">
                    <h5 class="card-title">
                        <?php echo $__env->make('auth.layouts.message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php if(Auth::user()->role == "manager"): ?>
                          <div class="d-flex justify-content-between">
                            <a href="<?php echo e(Route('tasks.create')); ?>" class="btn btn-primary">Add-New Task +</a>
                          </div>
                        <?php endif; ?>
                    </h5>
        
        
                    <!-- Table with stripped rows -->
                    <table class="table datatable">
                      <thead>
                        <tr>
                          <th>Sl.</th>
                          <th>
                            <b>T</b>ask title
                          </th>
                          <th>Project Name</th>
                          <th>Manager Name</th>
                          <th>Assigned To</th>
                          <th>Status</th>
                          <?php if(Auth::user()->role == "manager"): ?>
                          <th>Action</th>
                          <?php endif; ?>
                        </tr>
                      </thead>
                      <tbody>
        
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if(Auth::user()->role == "manager" || Auth::user()->id == $item->assigned_to): ?>
                              <tr>
                                  <td><?php echo e($loop->index + 1); ?></td>
                                  <td><?php echo e($item->title); ?></td>
                                  <td><?php echo e($item->project->project_name); ?></td>
                                  <td><?php echo e($item->manager->name); ?></td>
                                  <td><?php echo e($item->assignee->name); ?></td>
                                  <td>
                                      <form action="<?php echo e(Route('tasks.status')); ?>" method="GET">
                                          <input type="hidden" value="<?php echo e($item->id); ?>" name="token">
                                          <select name="status" class="form-select" onchange="this.form.submit()">
                                              <option value="Pending" <?php if($item->status == "Pending"): ?> selected <?php endif; ?>>Pending</option>
                                              <option value="Working" <?php if($item->status == "Working"): ?> selected <?php endif; ?>>Working</option>
                                              <option value="Done" <?php if($item->status == "Done"): ?> selected <?php endif; ?>>Done</option>
                                          </select>
                                      </form>
                                  </td>
                      
                                  <?php if(Auth::user()->role == "manager"): ?>
                                      <td style="min-width: 90px">
                                          <a href="<?php echo e(Route('tasks.edit', $item->id)); ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></a> 
                                          <a href="<?php echo e(Route('tasks.delete', $item->id)); ?>" onclick="return confirm('Are you sure you want to delete this record?');" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></a>
                                      </td>
                                  <?php endif; ?>
                              </tr>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
        
                      </tbody>
                    </table>
                    <!-- End Table with stripped rows -->
                </div>
            </div>
        </div>

    </div>
    </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Login Authentication\resources\views/tasks/index.blade.php ENDPATH**/ ?>