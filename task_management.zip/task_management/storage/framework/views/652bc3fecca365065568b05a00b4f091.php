
<?php $__env->startSection('section'); ?>

  <div class="pagetitle">
    <h1>Projects</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Home</a></li>
        <li class="breadcrumb-item active">Projects</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">

    <!-- Left side columns -->
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body" style="overflow-x: scroll;white-space: nowrap">
                    <h5 class="card-title">
                        <?php echo $__env->make('auth.layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="d-flex justify-content-between">
                          <a href="<?php echo e(Route('project.create')); ?>" class="btn btn-primary">Add-New Project +</a>
                        </div>
                    </h5>
        
        
                    <!-- Table with stripped rows -->
                    <table class="table datatable">
                      <thead>
                        <tr>
                          <th>Sl.</th>
                          <th>
                            <b>N</b>ame
                          </th>
                          <th>#P-Code</th>
                          <th>Manager Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
        
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->index+1); ?></td>
                          <td><?php echo e($item->project_name); ?></td>
                          <td><?php echo e($item->project_code); ?></td>
                          <td><?php echo e($item->manager->name); ?></td>
                          <td style="min-width: 90px">
                            <a href="<?php echo e(Route('project.edit',$item->id)); ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i></a> 
                            <a href="<?php echo e(Route('project.delete',$item->id)); ?>" onclick="return confirm('Are you sure you want delete record?');" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        
                      </tbody>
                    </table>
                    <!-- End Table with stripped rows -->
                </div>
            </div>
        </div>

    </div>
    </section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Login Authentication\resources\views/projects/index.blade.php ENDPATH**/ ?>