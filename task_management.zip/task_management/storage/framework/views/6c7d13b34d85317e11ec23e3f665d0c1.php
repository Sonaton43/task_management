
<?php $__env->startSection('section'); ?>

<div class="pagetitle">
  <h1>Dashboard</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item active">Dashboard</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section dashboard">
  <div class="row">
    <!-- Left side columns -->
    <div class="col-lg-12">
        <div class="row">

          <!-- Recent Sales -->
          <div class="col-12">
            <div class="card recent-sales overflow-auto">

              <div class="card-body">
                <h5 class="card-title">All Tasks <span>| </span></h5>

                <table class="table table-borderless datatable">
                  <thead>
                    <tr>
                      <th scope="col">#Project code</th>
                      <th scope="col">Project Name</th>
                      <th scope="col">Task Name</th>
                      <th scope="col">Manager Name</th>
                      <th scope="col">Assigned</th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><a href="#"><?php echo e($item->project->project_code); ?></a></th>
                        <td><?php echo e($item->project->project_name); ?></td>
                        <td><a href="#" class="text-primary"><?php echo e($item->title); ?></a></td>
                        <td><?php echo e($item->manager->name); ?></td>
                        <td><?php echo e($item->assignee->name); ?></td>
                        <td><span class="badge <?php if($item->status == "Pending"): ?> bg-danger <?php elseif($item->status == "Working"): ?> bg-warning <?php else: ?> bg-success <?php endif; ?> "><?php echo e($item->status); ?></span></td>
                      </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                  </tbody>
                </table>

              </div>

            </div>
          </div><!-- End Recent Sales -->

        </div>
    </div><!-- End Left side columns -->
  </div>
</section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Login Authentication\resources\views/dashboard.blade.php ENDPATH**/ ?>