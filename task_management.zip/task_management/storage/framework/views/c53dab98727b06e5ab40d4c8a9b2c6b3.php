<?php $__env->startComponent('mail::message'); ?>
<p>Hey,</p>
<h2>Welcome <?php echo e($user->email); ?></h2>
<p>If you  think Reset your Password by clicking the button below.</p>
<?php $__env->startComponent('mail::button',['url' => url('password/reset/'.$user->remember_token)]); ?>
Reset Password
<?php echo $__env->renderComponent(); ?>
<p>If you have any issus please contact our contact page.</p>
<p>Thanks</p>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/auth/emails/forgot.blade.php ENDPATH**/ ?>