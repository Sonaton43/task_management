<?php if(!empty(session('errorM'))): ?>
    <div class="alert alert-danger alert-dismissible alert-alt solid fade show">
         <button type="button" class="close h-100" data-dismiss="alert" aria-label="Close"><span><i class="mdi mdi-close"></i></span>
        </button>
        <strong>Error!</strong> <?php echo e(session('errorM')); ?>

    </div>
<?php endif; ?>
<?php if(!empty(session('error'))): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php if(!empty(session('primary-error'))): ?>
    <div class="alert alert-primary alert-dismissible fade show" role="alert">
        <?php echo e(session('primary-error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php if(!empty(session('success'))): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Login Authentication\resources\views/auth/layouts/message.blade.php ENDPATH**/ ?>