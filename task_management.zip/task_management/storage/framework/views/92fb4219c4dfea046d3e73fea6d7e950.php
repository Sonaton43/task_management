<!-- ======= Hrader Start ======= -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- =======  Hrader End  ======= -->

<?php echo $__env->yieldContent('authsection'); ?>

<!-- ======= Sidebar Start ======= -->
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- =======  Sidebar End  ======= -->

<?php /**PATH C:\laragon\www\Login Authentication\resources\views/auth/layouts/welcome.blade.php ENDPATH**/ ?>